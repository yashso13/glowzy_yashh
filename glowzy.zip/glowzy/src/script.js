function scrollToProducts() {
  document.getElementById("products").scrollIntoView({ behavior: "smooth" });
}

function openModal(title, description) {
  document.getElementById("modalTitle").innerText = title;
  document.getElementById("modalDescription").innerText = description;
  document.getElementById("productModal").style.display = "flex";
}

function closeModal() {
  document.getElementById("productModal").style.display = "none";
}

// Close the modal when clicking outside of it
window.onclick = function (event) {
  if (event.target == document.getElementById("productModal")) {
    closeModal();
  }
};
